# CloudProject

The app is deployed on heroku

Please run following links before running algorithm:

Before running the requests add aws credentials in header for all the three apis
aws_access_key_id
aws_secret_access_key
aws_session_token

Please check your email for screenshot

Create tables in dynamo db
GET https://cloudcourseapp.herokuapp.com/createtables

load data into dynamo db
GET https://cloudcourseapp.herokuapp.com/loaddata

No authorization required for create tables and load data

Run the algorithm
    POST https://cloudcourseapp.herokuapp.com/algo
    
    Authorization:
    Type    Basic Auth
    Username    John
    Password    mypassword
    
    BODY: 
    form-data
    key         value
    file        attach claimdata.json file here. it is present in the repository

